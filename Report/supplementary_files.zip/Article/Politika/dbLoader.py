import sqlite3

conn = sqlite3.connect('articleDB.db')

c = conn.cursor()

