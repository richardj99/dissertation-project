This project requires OpenJDK 13 & Python 3.7 (with TensorFlow, Tensorflow_datasets and pandas libraries installed).

Entry point of the program is reached by opening the .jar file using OJDK13.